# 🎨 Visual Setup Guide

A step-by-step visual guide to setting up SEENAF CTF Platform.

---

## 📍 Step 1: Prerequisites

### What You Need

```
┌─────────────────────────────────────────┐
│  ✓ Node.js 18+                          │
│  ✓ npm (comes with Node.js)             │
│  ✓ Git                                   │
│  ✓ Supabase Account (free)              │
│  ✓ Text Editor (VS Code recommended)    │
└─────────────────────────────────────────┘
```

### Check Your Installation

```bash
$ node --version
v18.17.0  ✓

$ npm --version
9.6.7  ✓

$ git --version
git version 2.40.0  ✓
```

---

## 📍 Step 2: Clone Repository

```
┌─────────────────────────────────────────┐
│  Terminal / Command Prompt              │
├─────────────────────────────────────────┤
│  $ git clone <repo-url>                 │
│  Cloning into 'seenaf-ctf-platform'...  │
│  ✓ Done                                 │
│                                          │
│  $ cd seenaf-ctf-platform               │
│  $ ls                                    │
│  README.md  package.json  src/  ...     │
└─────────────────────────────────────────┘
```

---

## 📍 Step 3: Install Dependencies

```
┌─────────────────────────────────────────┐
│  $ npm install                          │
├─────────────────────────────────────────┤
│  ⠋ Installing dependencies...           │
│  ✓ Added 1247 packages                  │
│  ✓ Done in 45s                          │
└─────────────────────────────────────────┘
```

**What's happening?**
- Downloading React, TypeScript, Vite
- Installing UI components (Radix, shadcn)
- Setting up Supabase client
- Configuring build tools

---

## 📍 Step 4: Create Supabase Project

### 4.1 Go to Supabase

```
Browser: https://supabase.com/
         ↓
      [Sign Up] or [Log In]
         ↓
      Dashboard
```

### 4.2 Create New Project

```
┌─────────────────────────────────────────┐
│  New Project                            │
├─────────────────────────────────────────┤
│  Name: SEENAF CTF Platform              │
│  Database Password: ••••••••••          │
│  Region: [Select closest to you]        │
│                                          │
│  [Create new project]                   │
└─────────────────────────────────────────┘
```

**Wait 2-3 minutes for setup...**

```
Setting up your project...
▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ 100%
✓ Project ready!
```

### 4.3 Get Your Credentials

```
┌─────────────────────────────────────────┐
│  Settings → API                         │
├─────────────────────────────────────────┤
│  Project URL:                           │
│  https://xxxxx.supabase.co              │
│                                          │
│  Project ID:                             │
│  xxxxx                                   │
│                                          │
│  anon/public key:                        │
│  eyJhbGciOiJIUzI1NiIsInR5cCI6...        │
│                                          │
│  [Copy these values!]                   │
└─────────────────────────────────────────┘
```

---

## 📍 Step 5: Configure Environment

### Option A: Automated Setup (Recommended)

```
┌─────────────────────────────────────────┐
│  $ npm run setup                        │
├─────────────────────────────────────────┤
│  🚀 SEENAF CTF - Supabase Setup         │
│                                          │
│  Supabase URL: https://xxxxx.supabase.co│
│  ✓ Project ID detected: xxxxx           │
│                                          │
│  Anon Key: eyJhbGci...                  │
│                                          │
│  ✓ .env file created successfully!      │
└─────────────────────────────────────────┘
```

### Option B: Manual Setup

```
┌─────────────────────────────────────────┐
│  1. Copy .env.example to .env           │
│  $ cp .env.example .env                 │
│                                          │
│  2. Edit .env file                       │
│  VITE_SUPABASE_PROJECT_ID=xxxxx         │
│  VITE_SUPABASE_PUBLISHABLE_KEY=eyJ...   │
│  VITE_SUPABASE_URL=https://xxxxx...     │
│                                          │
│  3. Save the file                        │
└─────────────────────────────────────────┘
```

---

## 📍 Step 6: Set Up Database

### 6.1 Open SQL Editor

```
Supabase Dashboard
    ↓
SQL Editor (left sidebar)
    ↓
[New Query]
```

### 6.2 Run Setup Script

```
┌─────────────────────────────────────────┐
│  SQL Editor                             │
├─────────────────────────────────────────┤
│  1. Open: complete-setup.sql            │
│  2. Copy ALL contents                    │
│  3. Paste into SQL Editor                │
│  4. Click [Run] or Ctrl+Enter           │
│                                          │
│  Running query...                        │
│  ✓ Success. No rows returned            │
└─────────────────────────────────────────┘
```

**What's created:**
- ✓ `challenges` table
- ✓ `profiles` table
- ✓ `user_roles` table
- ✓ `submissions` table
- ✓ Row Level Security policies
- ✓ Database functions

### 6.3 Load Challenges

```
┌─────────────────────────────────────────┐
│  SQL Editor                             │
├─────────────────────────────────────────┤
│  1. [New Query]                         │
│  2. Open: load-all-68-challenges.sql    │
│  3. Copy and paste                       │
│  4. Click [Run]                          │
│                                          │
│  ✓ 68 challenges loaded successfully    │
└─────────────────────────────────────────┘
```

---

## 📍 Step 7: Verify Setup

```
┌─────────────────────────────────────────┐
│  $ npm run verify                       │
├─────────────────────────────────────────┤
│  🔍 Setup Verification                  │
│                                          │
│  Checking configuration files...         │
│  ✓ .env file exists                     │
│                                          │
│  Checking environment variables...       │
│  ✓ VITE_SUPABASE_URL is set             │
│  ✓ VITE_SUPABASE_PUBLISHABLE_KEY is set │
│  ✓ VITE_SUPABASE_PROJECT_ID is set      │
│                                          │
│  Checking dependencies...                │
│  ✓ Dependencies installed                │
│                                          │
│  Testing Supabase connection...          │
│  ✓ Successfully connected to Supabase   │
│  ✓ Found 68 challenges in database      │
│  ✓ Table 'profiles' exists              │
│  ✓ Table 'user_roles' exists            │
│  ✓ Table 'submissions' exists           │
│                                          │
│  🎉 All checks passed!                  │
└─────────────────────────────────────────┘
```

---

## 📍 Step 8: Start Development Server

```
┌─────────────────────────────────────────┐
│  $ npm run dev                          │
├─────────────────────────────────────────┤
│  VITE v5.4.19  ready in 500 ms          │
│                                          │
│  ➜  Local:   http://localhost:5173/     │
│  ➜  Network: use --host to expose       │
│                                          │
│  ✅ Supabase connected successfully     │
└─────────────────────────────────────────┘
```

### Open in Browser

```
Browser: http://localhost:5173
         ↓
    ┌─────────────────────────┐
    │   SEENAF CTF Platform   │
    │   ═══════════════════   │
    │                         │
    │   [Sign Up] [Log In]    │
    │                         │
    │   68 Challenges Ready   │
    └─────────────────────────┘
```

---

## 📍 Step 9: Create Admin Account

### 9.1 Register User

```
Browser → Sign Up
    ↓
┌─────────────────────────────────────────┐
│  Create Account                         │
├─────────────────────────────────────────┤
│  Email: your-email@example.com          │
│  Password: ••••••••••                   │
│  Confirm: ••••••••••                    │
│                                          │
│  [Sign Up]                              │
└─────────────────────────────────────────┘
```

### 9.2 Grant Admin Access

```
┌─────────────────────────────────────────┐
│  Supabase → SQL Editor                  │
├─────────────────────────────────────────┤
│  1. Open: emergency-admin-fix-v2.sql    │
│  2. Find line:                           │
│     WHERE email = 'your-email@...'      │
│  3. Replace with YOUR email             │
│  4. Run the script                       │
│                                          │
│  ✓ Admin role granted successfully      │
└─────────────────────────────────────────┘
```

### 9.3 Access Admin Panel

```
Browser → Log out → Log in again
    ↓
Navigate to: /admin
    ↓
┌─────────────────────────────────────────┐
│  Admin Panel                            │
├─────────────────────────────────────────┤
│  ✓ Challenge Management                 │
│  ✓ User Management                       │
│  ✓ Platform Statistics                   │
│  ✓ Debug Tools                           │
└─────────────────────────────────────────┘
```

---

## 📍 Step 10: Test Everything

### Checklist

```
┌─────────────────────────────────────────┐
│  Testing Checklist                      │
├─────────────────────────────────────────┤
│  [ ] Homepage loads                      │
│  [ ] Can register new user               │
│  [ ] Can log in                          │
│  [ ] Challenges page shows 68 challenges │
│  [ ] Can view challenge details          │
│  [ ] Can submit a flag                   │
│  [ ] Leaderboard displays                │
│  [ ] Admin panel accessible              │
│  [ ] Can create new challenge            │
│  [ ] No console errors                   │
└─────────────────────────────────────────┘
```

---

## 🎉 Success!

```
┌─────────────────────────────────────────┐
│                                          │
│         🎉 Setup Complete! 🎉           │
│                                          │
│  Your SEENAF CTF Platform is ready!     │
│                                          │
│  ✓ 68 Challenges loaded                 │
│  ✓ Admin access configured               │
│  ✓ Database connected                    │
│  ✓ Development server running            │
│                                          │
│  Next Steps:                             │
│  • Customize branding                    │
│  • Add your own challenges               │
│  • Invite users                          │
│  • Deploy to production                  │
│                                          │
└─────────────────────────────────────────┘
```

---

## 🆘 Troubleshooting Visual Guide

### Problem: Connection Failed

```
❌ Error: Cannot connect to Supabase
    ↓
Check .env file
    ↓
┌─────────────────────────────────────────┐
│  VITE_SUPABASE_URL=https://xxxxx...     │
│  VITE_SUPABASE_PUBLISHABLE_KEY=eyJ...   │
│  VITE_SUPABASE_PROJECT_ID=xxxxx         │
└─────────────────────────────────────────┘
    ↓
Verify credentials in Supabase Dashboard
    ↓
Restart dev server: npm run dev
```

### Problem: No Challenges

```
❌ Error: No challenges showing
    ↓
Check Supabase Table Editor
    ↓
┌─────────────────────────────────────────┐
│  Table: challenges                      │
│  Rows: 0                                │
└─────────────────────────────────────────┘
    ↓
Run: load-all-68-challenges.sql
    ↓
Refresh browser
```

### Problem: Admin Access Denied

```
❌ Error: Access denied to admin panel
    ↓
Check user_roles table
    ↓
┌─────────────────────────────────────────┐
│  user_id  │  role                       │
│  (empty)  │                             │
└─────────────────────────────────────────┘
    ↓
Run: emergency-admin-fix-v2.sql
    ↓
Log out and log in again
```

---

## 📊 Architecture Overview

```
┌─────────────────────────────────────────┐
│  Browser (React + TypeScript)           │
│  ├─ Components (UI)                     │
│  ├─ Pages (Routes)                      │
│  ├─ Hooks (State)                       │
│  └─ Utils (Helpers)                     │
└─────────────────────────────────────────┘
            ↕ (API Calls)
┌─────────────────────────────────────────┐
│  Supabase (Backend)                     │
│  ├─ PostgreSQL Database                 │
│  ├─ Authentication                       │
│  ├─ Row Level Security                   │
│  └─ Real-time Subscriptions             │
└─────────────────────────────────────────┘
```

---

## 🎯 Quick Reference

### Essential Commands

```bash
npm run setup      # Configure Supabase
npm run verify     # Check setup
npm run dev        # Start dev server
npm run build      # Build for production
```

### Essential Files

```
.env                              # Your credentials
complete-setup.sql                # Database setup
load-all-68-challenges.sql        # Challenge data
emergency-admin-fix-v2.sql        # Admin access
```

### Essential URLs

```
Local:      http://localhost:5173
Admin:      http://localhost:5173/admin
Supabase:   https://app.supabase.com
```

---

**🎉 You're all set! Happy hacking! 🏴‍☠️**
